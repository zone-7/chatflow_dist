//删除
function remove(code){
    isconfirm("确认删除流程？",  function(){

        http.post(http_url_namespace+"/flow/remove", {flow_code: code}, "form", function(res){
            if(res.code==0){ 
                toastr.success(res.msg); 
                loadAll(); 
            }else{
                toastr.error(res.msg);
            }
        });

    } );
}
//克隆
function clone(code,title){
    http.post(http_url_namespace+"/flow/clone", {flow_code: code, flow_name: title}, "form", function(res){
        if(res.code==0){ 
            toastr.success(res.msg); 
            loadAll(); 
        }else{
            toastr.error(res.msg);
        }
    });
}

function showClone(code){
    prompt_confirm("请输入名称：",function(value){ 
        clone(code, value);
    });
}

//列出所有流程
function loadAll(){
    var token = localStorage.getItem("token");
    http.post(http_url_namespace+"/flow/list", {}, "form", function(res){
        if(res.code==0){
            var list = res.obj;
            
            $("#flow_list").find(".flow-item").each(function(index,e){
              $(e).remove();
            });

            for(var i in list){
                var item = list[i];
                var pageUrl =  '/design?flow_code='+item.code;
                var html='<div class="col-lg-3 col-md-12 col-sm-12 flow-item p-2 grid-margin stretch-card">'+
                '<div class="card card-outline card-outline-primary">'+ 
                '<div class="card-header">'+
                '<div class="card-title">'+  
                
                '<a href="#" onclick="goPage(\''+pageUrl+'\');return false;"  >'+
                '<img  class="flow-item-icon"/> '+
                item.name+'</a>'+
                
                '</div>'+ //end cardtitle
                '<div class="card-tools">'+ 
                '<button class="btn btn-tool" onclick="goPage(\''+pageUrl+'\')"><i class="fas fa-edit"></i></button>'+

                '<button class="btn btn-tool" onclick="showClone(\''+item.code+'\')"><i class="fas fa-copy"></i></button>'+

                '<button class="btn btn-tool" onclick="remove(\''+item.code+'\')"><i class="fas fa-times"></i></button>'+
                '</div>'+ 
                '</div>'+ //end cardheader
                
                '<div class="card-body flow-item-body">'+

                '<div class="flow-item-content"  >'+


                '</div>'+  //end content

                '<a href="#" onclick="return false;"  >'+
                '<img src="'+http_url_namespace+'/flow/image/'+item.code+'?token='+token+'" class="flow-item-image"/>'+
                '</a>'+
               

                '</div>'+//end cardbody 
                
                '</div>'+//end card
                '</div>';//end flow-item
                
                var box = $(html);
                if(item.icon!=null && item.icon.length>0){
                    box.find(".flow-item-icon").attr("src",item.icon);
                }else{
                    box.find(".flow-item-icon").hide();
                }
                
                $("#flow_list").append(box); 
            }

        }else{
            toastr.error(res.msg);
        }
        
    });
}



$(function(){
  loadAll();

});
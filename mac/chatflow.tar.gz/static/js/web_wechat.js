
var flowList=[];  

function showError(msg){ 
  $("#error_box").show();
  $("#qrcode_box").hide();
  $("#user_box").hide();
  $("#error_box").find("label").html(msg);
}


function showUser(state){ 
  var user = state.user;
  var avatar = user.avatar||"";
  $("#error_box").hide(); 
  $("#qrcode_box").hide();
  $("#user_box").show();

  $("#user_box #user_avatar").attr("src", avatar);
  $("#user_box #user_nick_name").html(user.nick_name);
  $("#user_box #user_signature").html(user.signature||'');
  $("#user_box #user_flow_code").val(user.flow_code);

  //流程选择
  var optionsHtml = '<option value="">---空---</option>';
  for(var i in flowList){
      var item = flowList[i]; 
      optionsHtml+='<option value="'+item.code+'">'+item.name+'</option>'; 
  }
 

}

function showQrcode(state){ 
  $("#error_box").hide();  
  $("#qrcode_box").show();
  $("#user_box").hide();
  
  $("#qrcode").attr("src",state.qrcode_url);  
}


function showState(state){
 if(state && state.user!=null){
    showUser(state);
  }else if(state&& state.qrcode_url!=null && state.qrcode_url.length>0){
    showQrcode(state);
  }


}
//关闭
function logoutWechat(){

    isconfirm("确认退出微信用户？",  function(){ 
        http.post(http_url_namespace+"/wechat/logout", {}, "form", function(res){
            if(res.code==0){ 
                
            }else{
                toastr.error(res.msg);
            }
        });
    });
}


//打开微信
function loginWechat(hotlogin){
    http.post(http_url_namespace+"/wechat/login", {hotlogin: hotlogin}, "form", function(res){
        if(res.code==0){
           
        }else{
          showError(res.msg); 
        }
        
    });
}


//连接
function conn(){
    var protocol = "ws:";
    var path = http_url_namespace + "/wechat/conn";
    
    var host = window.location.host; 

    if(window.location.protocol=="https:"){
      protocol="wss:";
    }

    var url = protocol+"//"+host+path;
     
    
    websocket.onOpen=function(){ 
          
    };
    websocket.onClose=function(){   
        showError("连接关闭,请刷新页面！");
    };
    websocket.onError=function(){
      showError("系统异常，请刷新页面！");
    };

    websocket.onMessage=function(msg){

        var msgObj = JSON.parse(msg);
        
        if(msgObj.cmd_type=="wechat_state"){

          if(msgObj.content.length==0){
            loginWechat();
          }else{ 
            state = JSON.parse(msgObj.content); 
            if(state.state=="logout"){
              loginWechat();
            }else if(state.state=="qrcode"){
              showQrcode(state);
            }else if(state.state=="login"){
              showUser(state);
            } 
          }
         
        }
    };
    
    websocket.connect(url);

}

function changeUserFlowCode(){
  var flow_code = $("#user_box #user_flow_code").val();
  http.post(http_url_namespace+"/wechat/set_user_flow_code", {flow_code:flow_code}, "form", function(res){
        if(res.code==0){
          toastr.success(res.msg); 
        }else{
          toastr.error(res.msg); 
        }
        
    });
}
 
//加载所有流程列表
function loadFlows(callback){
    http.post(http_url_namespace+"/flow/list_active", {}, "form", function(res){
        if(res.code==0){
            var list = res.obj; 

            flowList = list;
            
            $("#user_flow_code").html('<option value="">---空---</option>'); 
            for(var i in flowList){
                var item = flowList[i]; 
                $("#user_flow_code").append('<option value="'+item.code+'">'+item.name+'</option>'); 
            }
            if(callback){
              callback();
            }

        }else{
            showError(res.msg);
        }
        
    });
}


 

$(function(){
  
  loadFlows(function(){
    conn();
  });
  
});

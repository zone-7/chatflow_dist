$(function(){
    getVersion(function(version){
        $("#version").html(version);
    });
});
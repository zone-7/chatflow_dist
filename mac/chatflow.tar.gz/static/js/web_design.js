 

var loading_messages = false;
var message_page_size= 10;
var current_message_start = 0;

var input_type_options=[];
var currentFlowCode; 
var currentLinkInfo;
var currentActionInfo;  

toastr.options = { 
    "closeButton": true,
    "showDuration": "300",//显示动作时间
    "hideDuration": "300",//隐藏动作时间
    "positionClass": "toast-center-center" 
};

 
function getUserId(){
    var userid = window.localStorage.getItem("chartflow_userid");
    if(userid==null || userid==""){
        userid=guid();
        window.localStorage.setItem("chartflow_userid", userid);
    }
    return userid;
}

function getSessionId(){
    var session_id = window.localStorage.getItem("chartflow_sessionid_"+currentFlowCode);
    if(session_id==null || session_id==""){
        session_id=guid();
        window.localStorage.setItem("chartflow_sessionid_"+currentFlowCode, session_id);
    }
    return session_id;
}

function setSessionId(session_id){
    window.localStorage.setItem("chartflow_sessionid_"+currentFlowCode,session_id);
}

//打开连接线配置对话框
function openLinkDialog(link){
    currentLinkInfo = link;
 
    var dialog = document.getElementById("linkDialog");
    dialog.querySelector("input[name='source_id']").value = link.source_id;
    dialog.querySelector("input[name='target_id']").value = (link.target_id);
    dialog.querySelector("input[name='title']").value = (link.title||"");
    dialog.querySelector("input[name='keywords']").value = (link.keywords||"");

    dialog.querySelector("input[name='label_source']").value= link.label_source||"";
    dialog.querySelector("input[name='label_target']").value = (link.label_target||"");
    dialog.querySelector("select[name='animation']").value = (link.animation?"true":"false");

    var arrows = link.arrows||[false,false,true];

    dialog.querySelector("select[name='arrows1']").value = (arrows[0]?"true":"false");
    dialog.querySelector("select[name='arrows2']").value = (arrows[1]?"true":"false");
    dialog.querySelector("select[name='arrows3']").value = (arrows[2]?"true":"false");

    dialog.querySelector("select[name='active']").value = (link.active||"true");
    dialog.querySelector("textarea[name='filter']").value = (link.filter||"");
     

    $("#linkDialog").modal("show");
}

function saveLinkDialog(){ 
    if(currentLinkInfo==null){
        return;
    }
    var dialog = document.getElementById("linkDialog");
    currentLinkInfo.title = dialog.querySelector("input[name='title']").value;
    currentLinkInfo.keywords = dialog.querySelector("input[name='keywords']").value;
    currentLinkInfo.label_target = dialog.querySelector("input[name='label_target']").value;
    currentLinkInfo.label_source = dialog.querySelector("input[name='label_source']").value;
    currentLinkInfo.animation = dialog.querySelector("select[name='animation']").value=="true"?true:false;
    var arrows=[false,false,true];
    if(dialog.querySelector("select[name='arrows1']").value=="true"){
        arrows[0]=true
    }
    if(dialog.querySelector("select[name='arrows2']").value=="true"){
        arrows[1]=true
    }
    if(dialog.querySelector("select[name='arrows3']").value=="true"){
        arrows[2]=true
    }
    currentLinkInfo.arrows = arrows;
    currentLinkInfo.active = dialog.querySelector("select[name='active']").value;
    currentLinkInfo.filter = dialog.querySelector("textarea[name='filter']").value;

    andflow.setLinkInfo(currentLinkInfo);
    $("#linkDialog").modal("hide");
}

//打开节点配置对话框
function openActionDialog(action){
    currentActionInfo = action;
  
    if(actions[action.name]){
        actions[action.name].load(action);
        
        $('#'+actions[action.name].id+' .nav a:first').tab('show'); 
        $("#"+actions[action.name].id).modal("show");

    }
 
    
}

 
//保存action设置对话框数据
function saveActionDialog(){
    if(currentActionInfo==null){
        return;
    }

    if(actions[currentActionInfo.name]){
        actions[currentActionInfo.name].save(currentActionInfo);
 
        $("#"+actions[currentActionInfo.name].id).modal("hide"); 

        andflow.setActionInfo(currentActionInfo);
    } 
}

//截图
function snap(){
    andflow.snap("流程");
}

function showWait(msg){
    $("#wait_mask").show();
    $("#wait_mask label").html(msg||"");
}
function closeWait(){
    $("#wait_mask").hide();
}


function showConnBox(){
    $(".connecting-box .offline-info").show();
    $(".connecting-box .connecting-info").hide();
    $(".connecting-box").show();
}

function closeConnBox(){
    $(".connecting-box").hide();
}

function reconn(){
    $(".connecting-box .offline-info").hide();
    $(".connecting-box .connecting-info").show();

    conn();
}

//创建新的流程
function create(){
    
    var model = {code:"",name:"",show_action_body:"true",show_action_content:"true", theme:"flow_theme_default",link_type:"Flowchart"};
 
    showAndflow(model);

    $("#flow_code").val("");
    $("#flow_name").val(""); 
    $("#flow_title").val(""); 
    
    $("#flow_timeout").val("60000");  
    $("#session_timeout").val("300000"); 
    $("#description").val(""); 
    $("#waitting_text").val("");
    $("#order_num").val(1);

    $("#flow_name").focus();
    
}

//添加字典
function appendFlowParam(param,index){
    if(!index){
        index=$("#flow_param_list").children().length+1;
    }

    var options = '';
    for(var i in input_type_options){
        var value = input_type_options[i].value;
        var label = input_type_options[i].label;

        options += '<option value="'+value+'">'+label+'</option>';
    }


    param = param||{};

    var html= '<div class="param-box card card-default mb-1">'+
    '<div class="card-header border-0 p-0" >'+
    '<div class="card-title p-1"><span class="badge badge-info">'+(index||'')+'</span></div>'+ 
    
    '<div class="card-tools">'+ 
    '<button class="btn btn-tool" onclick="upFlowParam(this);"><i class="fa fa-arrow-up"></i></button>'+
    '<button class="btn btn-tool" onclick="downFlowParam(this);"><i class="fa fa-arrow-down"></i></button>'+
    '<button class="btn btn-tool" onclick="deleteFlowParam(this);"><i class="fa fa-times"></i></button>'+
    '</div>'+//end tools
    '</div>'+//end header
    '<div class="card-body p-2">'+

    '<div class="form-group">'+
    '<label>名称</label>'+
    '<input name="name" class="form-control form-control-sm" type="text" autocomplete="off" placeholder="名称" />'+
    '</div>'+

    '<div class="form-group">'+
    '<label>标签</label>'+
    '<input name="label" class="form-control form-control-sm" type="text" autocomplete="off" placeholder="标签"  />'+
    '</div>'+

    '<div class="form-group">'+ 
    '<label>描述</label>'+
    '<input name="description" class="form-control form-control-sm"   autocomplete="off" placeholder="描述" />'+
    '</div>'+

    '<div class="form-group">'+
    '<label>默认值</label>'+
    '<textarea name="value" class="form-control form-control-sm"  autocomplete="off" placeholder="默认值" rows="4" ></textarea>'+
    '</div>'+

    '<div class="form-group">'+
    '<label>调试值</label>'+
    '<textarea name="debug_value" class="form-control form-control-sm"  autocomplete="off" placeholder="调试值"  rows="4" ></textarea>'+
    '</div>'+

    '<div class="form-group">'+
    '<label>输入框</label>'+
    '<select name="input_type" class="form-control form-control-sm"  autocomplete="off" placeholder="输入框"   >'+
     
    options+

    '</select>'+
    '</div>'+
    '</div></div>';


    
    var itemEl=$(html);
    itemEl.find("input[name='name']").val(param.name||'');
    itemEl.find("input[name='label']").val(param.label||'');
    itemEl.find("input[name='description']").val(param.description||' ');

    itemEl.find("textarea[name='value']").val(param.value||'');
    itemEl.find("textarea[name='debug_value']").val(param.debug_value||'');
    itemEl.find("select[name='input_type']").val(param.input_type||'');

    
    $("#flow_param_list").append(itemEl);

}

//删除参数
function deleteFlowParam(obj){
    isconfirm("确认删除？",function(){
        $(obj).parent().parent().parent().remove();
    });
    
}
//排序up
function upFlowParam(obj){
    var card = $(obj).parent().parent().parent();
    card.prev().before(card);
}
//排序down
function downFlowParam(obj){
    var card = $(obj).parent().parent().parent();
    card.next().after(card);
}

//显示字典
function showFlowParams(chatflow){
    var params = chatflow.params;
  

    $("#flow_param_list").html("");
    if(params){
        for(var i in params){
            var item = params[i];
            appendFlowParam(item,i*1+1);
        }
    }
}

//获取字典
function getFlowParams(){
    var items = [];
    $("#flow_param_list").children().each(function(index,el){
        var name = $(el).find("input[name='name']").val();
        var label = $(el).find("input[name='label']").val();
        var description = $(el).find("input[name='description']").val();

        var value = $(el).find("textarea[name='value']").val();
        var debug_value = $(el).find("textarea[name='debug_value']").val();
        var input_type = $(el).find("select[name='input_type']").val();

        items.push({name:name,label:label,description:description,value:value, debug_value: debug_value, input_type:input_type});
    });
    return items;
}

//显示参数
function showFlowProp(chatflow){
    var flowModel = chatflow.model;

    $("#flow_code").val(chatflow.code);
    $("#flow_name").val(chatflow.name); 
    $("#flow_title").val(chatflow.title);
    $("#description").val(chatflow.description||"");

    $("#flow_timeout").val(flowModel.timeout);
    $("#flow_theme").val(flowModel.theme);

    $("#session_timeout").val(chatflow.session_timeout || 300000);
    $("#waitting_text").val(chatflow.waitting_text||"");
    $("#order_num").val(chatflow.order_num||1);
    $("#active").val(chatflow.active||"true");

    $("#icon_img").on("error",function(e){
        this.src = http_url_namespace+'/static/img/empty.png';
    });

    $("#icon_img").attr("src", chatflow.icon);
    $("#icon_img").attr("data", chatflow.icon);
    

}

//从新加载
function reloadFlow(){
    loadFlow(currentFlowCode); 
}
//加载
function loadFlow(flow_code){

    if(flow_code==null || flow_code==''){ 
        return;
    }
 
    showWait("正在加载流程设计信息...");
    http.post(http_url_namespace+"/design/load", {flow_code: flow_code}, "form", function(res){
        if(res.code==0){
            var chatflow_designer = res.obj;
            console.info(chatflow_designer);
            var chatflow=chatflow_designer.chat_flow;
            input_type_options = chatflow_designer.input_type_options;

            var flowModel = chatflow.model; 
            currentFlowCode = flowModel.code;
             
            showFlowProp(chatflow);
            showFlowParams(chatflow);

            showAndflow(flowModel);
              

        }else{
            $("#flow_container").hide();
            $("#toolbar").hide();
            toastr.error(res.msg); 
        }
        closeWait();

    },function(err){ 
        toastr.error(err);

        closeWait();
        
    });
}

 
//保存截图
function saveImage(flow_code){
    andflow.getSnapshot(
      function (canvas) { 
        var url = canvas.toDataURL('image/jpeg'); //生成下载的url
        //保存截图
        http.post(http_url_namespace+"/flow/save_image", {flow_code:flow_code, image: url}, "form", function(res){
             
        },function(err){
            
        }); 
         
      }
    ); 
}
//保存
function saveFlow(){
 
    var flow_code = $("#flow_code").val()||"";
    var flow_name = $("#flow_name").val()||"";
    var flow_title = $("#flow_title").val()||"";

    var flow_timeout = $("#flow_timeout").val()||"";
    var flow_theme = $("#flow_theme").val()||"flow_theme_default";

    var session_timeout = $("#session_timeout").val() || 300000;
    var description = $("#description").val()||"";
    var waitting_text = $("#waitting_text").val()||"";
    var order_num = $("#order_num").val()*1;

    var icon = $("#icon_img").attr("data");

    var active = $("#active").val()||"true";

 
    if(flow_name==null || flow_name==""){
        toastr.error("名称不能为空");
        $("#flow_name").focus();
        return;
    }
    if(flow_title==null || flow_title==""){
        toastr.error("标题不能为空");
        $("#flow_title").focus();
        return;
    }
    if(flow_timeout*1<0 || flow_timeout*1>1800000){
        toastr.error("超时时间必须在：0~1800000 范围");
        $("#flow_timeout").focus();
        return;
    }

    var params = getFlowParams();
     

    flow_name = flow_name || 'andflow';
  
    var flow = andflow.getFlow();
    flow.name = flow_name;
    flow.code = flow_code;
    flow.theme = flow_theme;
    flow.timeout = flow_timeout;
     

    flow.show_action_body = flow.show_action_body || "true";
    flow.show_action_content = flow.show_action_content || "true";
    
   
    var chatflow = {
        code: flow_code,
        name: flow_name,
        title: flow_title,
        session_timeout: session_timeout *1,
        description: description,
        waitting_text: waitting_text,
        order_num: order_num,
        icon:icon,
        active: active,
        params: params,
        model: flow
    };


    var data = JSON.stringify(chatflow);

    showWait("正在保存...");
    http.post(http_url_namespace+"/flow/save", {content: data}, "form", function(res){
        if(res.code==0){
            $("#flow_code").val(res.obj.code);

            currentFlowCode = res.obj.code;
              
            saveImage(res.obj.code);
            
            reloadFlow();

            toastr.success(res.msg);
        }else{
            toastr.error(res.msg);
        }
        closeWait();
    },function(err){
        toastr.error(err);
        closeWait();
    }); 
}



//显示运行时状态
function showRuntime(runtime){
    var actionstates = runtime.action_states;
    var linkstates = runtime.link_states;    
    andflow.setActionStates(actionstates);
    andflow.setLinkStates(linkstates); 
}

function changeTheme(){
    var  theme = $("#flow_theme").val();

    andflow.setTheme(theme);
}
//显示流程
function showAndflow(flowModel){
    $("#flow_container").show();

    var options={
        tags:meta.tags,            //组件过滤标签列表
        metadata:meta.meta_data,    //组件元素
        flowModel:flowModel,  //流程模型
        img_path: http_url_namespace+"/static/img/meta/",
        editable:true,   //是否可编辑，默认true
        show_toolbar: true, 
        metadata_position: 'default', //top,left,default
        render_action:function(metadata,action,html){ return null; },//节点渲染
        render_action_helper: function(metadata,html){return null},  //节点拖拉渲染
        render_state_list: function(datas){return null},             //流程状态列表渲染
        render_link:function(conn,linktype,linkdata){return null},   //连接线渲染
        event_group_click:function(group){
            
        },
        event_group_dblclick: function(group){
        
        },
        //节点单击事件
        event_action_click:function(metadata,action){
 
        },
        //节点双击事件
        event_action_dblclick:function(metadata,action){
            openActionDialog(action); 
        },
        //连线单击事件
        event_link_click: function (link) {
        },
        //连线双击事件
        event_link_dblclick: function (link) {
            openLinkDialog(link);
        },
        //画图板单击事件
        event_canvas_click: function(e){ 
        }
    }


    andflow.newInstance("andflow",options);
    andflow.showFlow();
 
}
 
//连接
function conn(){
    var protocol = "ws:";
    var path = http_url_namespace + "/im/conn";
    
    var host = window.location.host; 

    if(window.location.protocol=="https:"){
      protocol="wss:";
    } 
    var ws_url = protocol+"//"+host+path;
    
    
    websocket.onOpen=function(){  
        closeConnBox();
    };
    websocket.onClose=function(){   
        showConnBox();
    };
    websocket.onError=function(){
        showConnBox();
    };

    websocket.onMessage=function(msg){

        var msgObj = JSON.parse(msg);
        if(msgObj.message_type=="message" ||msgObj.message_type=="waiting"){
            
            appendMessage(msgObj,false,true);  
             
        }else if(msgObj.message_type=="runtime"){
            var runtime = JSON.parse(msgObj.content);
            showRuntime(runtime);
        }else if(msgObj.message_type=="session"){

            if(msgObj.session_id!=null && msgObj.session_id.length>0){
        
                var sessionbtn = $("#message_list").find("a[session_id='"+msgObj.session_id+"']");
                 
                if(sessionbtn==null || sessionbtn.length<=0){
                   var infos = JSON.parse(msgObj.content);
                    showSessions(infos);
                }
            }
            

        }
    };
    
    websocket.connect(ws_url);
    
    
}

function scrollToBottom() { 

    var body =  $("#message_list");
    body.scrollTop(body.prop("scrollHeight"));

}

function onCopy(el){
    var id = $(el).attr("id"); 
    try{
        var clipboard = new ClipboardJS("#"+id);
        clipboard.on('success', function (e) { 
            e.clearSelection();
            clipboard.destroy(); 
        });

        clipboard.on('error', function (e) { 
            clipboard.destroy();
        }); 
    }catch(e){
        alert(e);
    }
}
//清空对话消息
function clearMessages(){
    $("#message_list").html("");
}

//追加信息
function appendMessage(msg, prepend, toBottom){
    if(prepend==undefined){
        prepend = false;
    } 
    if(toBottom==undefined){
        toBottom == false;
    }

    var message_id=msg.message_id;
    
    $("#message_list").find("[message_type='waiting']").remove();

    var chat_row=$("#"+message_id);
    if(!chat_row.length){
        chat_row = $('<div id="'+message_id+'" class="chat-row" message_type="'+msg.message_type+'" format="'+(msg.format||"")+'"></div>');
        
       
        const timeString = new Date(msg.send_time).toLocaleString(); 
        var user_info = ""; 
        if(msg.role=="user"){
            chat_row.addClass("right"); 
            user_info = $('<div class="chat-info"><img src="'+http_url_namespace+'/static/img/user.png" class="img-circle elevation-1" /><label class="chat-username"></label><div class="chat-time"><label>'+timeString+'</label></div></div>');

        }else{
            chat_row.addClass("left");
            user_info = $('<div class="chat-info"><img src="'+http_url_namespace+'/static/img/ai.png" class="img-circle elevation-1" /><label class="chat-username"></label><div class="chat-time"><label>'+timeString+'</label></div></div>');
        } 
        
        chat_row.append(user_info);


        var box = $('<div class="chat-box"></div>');
        
        if(msg.role!="user"){
            box.append('<div class="chat-toolbar"><a id="chat_copy_'+message_id+'" data-clipboard-target="#chat_item_'+message_id+'" class="btn btn-sm btn-light border-0" onclick="onCopy(this);" ><i class="fa fa-copy"></i></a></div>');

        }
         
        box.append('<div id="chat_item_'+message_id+'" class="chat-item"></div>');
        
        chat_row.append(box);

        if(prepend){
            $("#message_list").prepend(chat_row);
        }else{
            $("#message_list").append(chat_row);
        }
         
    }
 
    var content = msg.content;
    
    var oldcontent = chat_row.find(".chat-item").attr("content")||'';
    var newcontent = oldcontent+content;
    chat_row.find(".chat-item").attr("content",newcontent);
 

    marked.use({
          async: true,
          headerIds: false,
          mangle: false,
          langPrefix: 'hljs language-', 
          highlight: function(code, lang) {
            const language = hljs.getLanguage(lang) ? lang : 'javascript';
            return hljs.highlight(code, { language }).value;
          },
          
    });  
    marked.parse(newcontent).then(res=>{ 
        chat_row.find(".chat-item").html(res); 

        chat_row.find(".chat-item").find("code").each((index,el) => { 
        
            var codeid = $(el).attr("id"); 
            if(!codeid){
                codeid = "code_"+guid();
                $(el).attr("id",codeid);
            } 
            
            if($(el).text().length>20){
                var toolbar =  $(el).parent().find("div.code-toolbar");
                if(toolbar==null || toolbar.length==0){
                    var copyid = "btn_"+guid(); 
                    $('<div class="code-toolbar"><a id="'+copyid+'" data-clipboard-target="#'+codeid+'" class="btn btn-sm btn-outline-primary border-0" onclick="onCopy(this);"><i class="fa fa-copy"></i>Copy</a></div>').insertBefore($(el));
                }  
            }
           
     
        }); 
        if(toBottom){
            //滚动到最下
            scrollToBottom();
        }
    });  

   
     
}

//回车发送
function messageKeydown(event){
   
    if((event.ctrlKey || event.shiftKey || event.metaKey) && event.keyCode === 13) {
        $("#message").val($("#message").val()+"\n");
        return false;
    }else if (event.keyCode === 13){
        sendMessage();
        return false;
    }
 
    return true;
}

//发送信息
function sendMessage(){
    var content = $("#message").val();

    if(content.length==0){
        return;
    }

    var session_id = getSessionId();
    var user_id = getUserId();

    var flow_params = getFlowParams();
    var params = {};
    for(var i in flow_params){
        var name = flow_params[i].name;
        var value = flow_params[i].debug_value||flow_params[i].value;
        params[name]=value;
    }

    var msg={
        message_id: guid(),
        session_id: session_id,
        user_id:user_id,
        flow_code: currentFlowCode,
        message_type:"message",
        role:"user",
        format:"text",
        params: params,
        content: content,
        send_time: Date.now()
    };
    
    appendMessage(msg, false,  true);

    var msgJson = JSON.stringify(msg);

    websocket.send(msgJson);

    document.getElementById("message").innerHTML = "";
    $("#message").html("");
    $("#message").val("");
    
    $("#message").focus();
}


//加载历史消息
function loadMessages(start,size, callback){
    
    if(start==undefined){
        start=0;
    }
    
    if(size==undefined){
        size=message_page_size;
    }
    
    var session_id = getSessionId(); 
    var user_id = getUserId();
    
    http.post(http_url_namespace+"/session/load_messages", {user_id: user_id, flow_code: currentFlowCode, session_id: session_id,start:start,size: size}, "form", function(res){
        if(res.code==0){
            var messages = res.obj;
            if(messages){
                if(callback){
                    callback(messages);
                }
            }
            
        }else{ 
            toastr.error(res.msg); 
        } 

    },function(err){ 
        toastr.error(err);  
    });

}

//新建会话
function newSession(){
    var session_id=guid();
     
    selectSession(session_id);

    clearMessages();

    $("#message").focus();
}
//切换选择会话
function selectSession(session_id){
    setSessionId(session_id);

    $("#session_list").find(".session-item").each(function(index,e){
        $(e).removeClass("select");
    });
    var item = $("#session_list").find(".session-item[session_id='"+session_id+"']");
    if(item.length>0){
        item.addClass("select");
    }
    clearMessages();
    loadMessages(0, message_page_size, function(messages){
        for(var i in messages){
            var msg=messages[i];
            
            appendMessage(msg,true, false);
            
        }

        setTimeout(scrollToBottom, 500);
    }); 
}
//显示会话列表
function showSessions(infos){
    
    $("#session_list").html("");

    if(infos){
                
        for(var i in infos){
            var info=infos[i];
            var title = info.title||''; 



            var item = $('<a session_id="'+info.id+'" class="session-item btn btn-sm btn-default" onclick="selectSession(\''+info.id+'\')">'+title+'</a>');
            
            if(info.id == getSessionId()){
                item.addClass("select");
            }

            $("#session_list").append(item);
            
        }
    }
}
//加载会话
function loadSessions(){
    $("#session_list").html("");

    var user_id=getUserId(); 

    http.post(http_url_namespace+"/session/load_infos", {user_id: user_id, flow_code: currentFlowCode}, "form", function(res){
        if(res.code==0){
            var infos = res.obj;
            showSessions(infos);
            
        }else{ 
            toastr.error(res.msg); 
        } 

    },function(err){ 
        toastr.error(err);  
    });
 

}


 

function initScrollEvent(){

    $("#message_list").on('scroll', function (e) {
        var obj = $(this);
       
        var pageHeight = obj.height();
        var scrollHeight = obj[0].scrollHeight; //滚动条高度
        var scrollTop = obj.scrollTop(); //滚动条top
     

        if (loading_messages == false && scrollTop < 0.02) {
            
           
            var start = $('.message-list').children().length;


            loadMessages(start, message_page_size, function (messages) { 
                
                for(var i in messages){
                    var msg=messages[i]; 
                    appendMessage(msg, true, false);
                }
         
            });
        }
      });
}
  
function initIconEvent(){

   // 初始化插件
    $("#icon").fileinput({
        language: 'zh',
        showUpload: false, 
        showCaption: false,//是否显示标题
        showPreview: false,
        showRemove:false,
        captionClass: "form-control-sm",
        browseClass: "btn btn-primary btn-sm",
        removeClass: "btn btn-default btn-sm",
        allowedFileExtensions: ['jpg', 'png', 'gif'],
        maxFileSize: 2000,
        maxFilesNum: 1,
        browseLabel:'选择',
        removeLabel:'删除',
        cancelLabel:'取消',
        msgPlaceholder:'请选择图片',
        dropZoneTitle: "上传图片建议64*64"
    
    });
    // 获取图片并base64编码
    $("#icon").on("filebatchselected", function(event, files) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var base64Img = e.target.result;
            $("#icon_img").attr("src",base64Img);
            $("#icon_img").attr("data",base64Img);
            console.log(base64Img);
        };
        reader.readAsDataURL(files[0]);
    });
    $('#icon').on('fileclear', function(event, id) { 
        $("#icon_img").attr("src","");
        $("#icon_img").attr("data","");
        
    });
}

$(function(){ 
    initIconEvent();
    initScrollEvent();

    conn();

    currentFlowCode =  getUrlParam("flow_code");

    if(currentFlowCode!=null && currentFlowCode!=""){
        loadFlow(currentFlowCode);
    }else{
        create(); 
    }
    
    loadSessions();
    
    loadMessages(0, message_page_size, function(messages){
        for(var i in messages){
            var msg=messages[i];
            
            appendMessage(msg,true, false);
            
        }

        setTimeout(scrollToBottom, 500);
    });


});
     
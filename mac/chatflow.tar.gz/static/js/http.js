var http = {
    options:{},
    post:function (url, param,  contenttype, success, error) {
      if (url.indexOf('?') > 0) {
        url += '&sjs=' + new Date().getTime();
      } else {
        url += '?sjs=' + new Date().getTime();
      }

      if (contenttype == 'form') {
        contenttype = 'application/x-www-form-urlencoded';
      }
      if (contenttype == 'json') {
        contenttype = 'application/json;charset=UTF-8';
      }
      var self = this;

      $.ajax({
        type: 'POST',
        url: url,
        cache: false,
        async: true, //false同步请求,true异步请求
        data: param,
        timeout: 10000,
        beforeSend: function (XMLHttpRequest) {
          var token = self.options.token;
          if(token==null || token.length==0){
            token = localStorage.getItem("token");
          }
          XMLHttpRequest.setRequestHeader('Content-Type', contenttype); 
          XMLHttpRequest.setRequestHeader('Token', token);
        },
        success: function (res) {
          if (success) {
            success(res);
          }
        },
        error: function (xhr, status, err) {
          if (error) {
            error(err.errMsg || '服务器访问错误');
          }
        },
      });
    },

    get:function(url,success,error){
      var self = this;
      $.ajax({
        type: 'GET',
        url: url,
        cache: false,
        async: true, //false同步请求,true异步请求
        timeout: 10000,
        beforeSend: function (XMLHttpRequest) {
          var token = self.options.token;
          if(token==null || token.length==0){
            token = localStorage.getItem("token");
          } 
          XMLHttpRequest.setRequestHeader('Token', token);
        },
        success: function (res) {
          if (success) {
            success(res);
          }
        },
        error: function (xhr, status, err) {
          if (error) {
            error(err.errMsg || '服务器访问错误');
          }
        },
      });
    }
};

var websocket={
    websocket:null,
    connected: false,
    runtime: null,

    connect: function (ws_url) {
        var self = this;

        if (self.connected) {
            self.close();  
        }
    
        console.info('开始连接');
        self.websocket = new WebSocket(ws_url);

        self.websocket.onopen = function () {
            console.info('连接打开成功');
            self.connected = true;
            if (self.onOpen) {
                self.onOpen();
            }
        };
        self.websocket.onerror = function (err) {
            console.info('连接失败');
            console.error(err);
            if (self.onError) {
                self.onError(err);
            }
        };
        self.websocket.onmessage = function (event) {
            let data = event.data;
            if (data.length == 0) {
                return;
            }
 
            if (self.onMessage) {
                self.onMessage(data);
            }
        };
        self.websocket.onclose = function () {
            self.connected = false;
            console.info('连接关闭');

            if (self.onClose) {
                self.onClose();
            }
        };
    },
    close:function(){
        var self = this;
        if(self.websocket){
            self.websocket.close();
        }
    },
    send:function(msg){
        var self = this;
        if (self.connected &&
            self.websocket.readyState == self.websocket.OPEN ) {
         
            self.websocket.send(msg); // 基于WebSocket连接发送消息
             
            console.log('send message:' + msg);
        }
    }
}
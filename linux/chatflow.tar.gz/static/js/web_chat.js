
var loading_messages = false;
var message_page_size= 10;
var current_message_start = 0;

var current_prompts = null;
 
var globalParams={};

var flowsMap={};  
var sessionMap={};

function getUserId(){
    var userid = window.localStorage.getItem("chartflow_userid");
    if(userid==null || userid==""){
        userid=guid();
        window.localStorage.setItem("chartflow_userid", userid);
    }
    return userid;
}

function getFlow(){
    try{
        var str = window.localStorage.getItem("chartflow_flow");
        if(str==null || str==""){
            return null;
        }
        var flow = JSON.parse(str);
        return flow;
    }catch(e){
        return null;
    }
}

function setFlow(flow){
    try{
        if(flow==null){
            window.localStorage.removeItem("chartflow_flow");
            return;
        }
        var str = JSON.stringify(flow); 
        window.localStorage.setItem("chartflow_flow",str);
    }catch(e){

    }
}

function getSessionId(){
    var flow = getFlow();
    if(flow==null){
        return;
    }
    var flow_code = flow.code;

    var session_id = window.localStorage.getItem("chartflow_sessionid_"+flow_code);
    if(session_id==null || session_id==""){
        session_id=guid();
        window.localStorage.setItem("chartflow_sessionid_"+flow_code, session_id);
    }
    return session_id;
}

function setSessionId(session_id){
    var flow = getFlow();
    if(flow==null){
        return;
    }
    var flow_code=flow.code;
    
    window.localStorage.setItem("chartflow_sessionid_"+flow_code,session_id);
}
     
function showWait(msg){
 
}
function closeWait(){
   
} 

function showConnBox(){
    $(".connecting-box .offline-info").show();
    $(".connecting-box .connecting-info").hide();
    $(".connecting-box").show();
}

function closeConnBox(){
    $(".connecting-box").hide();
}

function reconn(){
    $(".connecting-box .offline-info").hide();
    $(".connecting-box .connecting-info").show();

    conn();
}


//连接
function conn(){ 

    var protocol = "ws:";
    var path = http_url_namespace + "/im/conn";
    
    var host = window.location.host; 

    if(window.location.protocol=="https:"){
      protocol="wss:";
    }


    var ws_url = protocol+"//"+host+path;
       

    websocket.onOpen=function(){  
       
        closeConnBox();
    };
    websocket.onClose=function(){    
         
        showConnBox();
     
    };
    websocket.onError=function(){  
        console.error("connect error");
        showConnBox();
    };

    websocket.onMessage=function(msg){

        var msgObj = JSON.parse(msg);
        if(msgObj.message_type=="message" ||msgObj.message_type=="waiting"){
             
            appendMessage(msgObj, false, true);  

        }else if(msgObj.message_type=="session"){

            if(msgObj.session_id!=null && msgObj.session_id.length>0){
        
                setSessionId(msgObj.session_id);

                var sessionbtn = $("#message_list").find("a[session_id='"+msgObj.session_id+"']");
                 

                if(sessionbtn==null || sessionbtn.length<=0){
                   var infos = JSON.parse(msgObj.content);
                    showSessions(infos);
                }
            } 
        }
    };
    
    websocket.connect(ws_url);
    
}

function scrollToBottom() { 
    var body =  $(window);
    var sh = $("body").prop("scrollHeight");
    
    body.scrollTop(sh);
   
}

//清空对话消息
function clearMessages(){
    var flow = getFlow();
    if(flow!=null){
        $("#message_welcome .icon").attr("src",flow.icon); 
        $("#message_welcome .name").html(flow.name); 
        $("#message_welcome .description").html(flow.description); 
        
        $("#message_welcome").show();
    }

    
    $("#message_list").html("");
}

 
function onCopy(el){
    var id = $(el).attr("id"); 
    try{
        var clipboard = new ClipboardJS("#"+id);
        clipboard.on('success', function (e) { 
            e.clearSelection();
            clipboard.destroy(); 
        });

        clipboard.on('error', function (e) { 
            clipboard.destroy();
        }); 
    }catch(e){
        alert(e);
    }
}

//追加信息 
function appendMessage(msg, prepend , toBottom){
    if(prepend==undefined){
        prepend = false;
    } 
    if(toBottom==undefined){
        toBottom = false;
    }

    if(msg==null || msg.message_id==null || msg.message_id.length==0){
        return;
    }

    $(".message-welcome").hide();

    var message_id=msg.message_id;
 
    $("#message_list").find("[message_type='waiting']").remove();

    var chat_row=$("#"+message_id);

    if(!chat_row.length){

        //root 
        chat_row = $('<div id="'+message_id+'" class="chat-row" message_type="'+msg.message_type+'" format="'+(msg.format||"")+'"></div>');
        
        const timeString = new Date(msg.send_time).toLocaleString();

        //user info
        var user_info = ""; 
        if(msg.role=="user"){
            chat_row.addClass("right"); 
            user_info = $('<div class="chat-info"><img src="'+http_url_namespace+'/static/img/user.png"   /><label class="chat-username"></label><div class="chat-time"><label>'+timeString+'</label></div></div>');

        }else{
            var avatar=http_url_namespace+'/static/img/ai.png';

            if(msg.flow_code!=null && flowsMap[msg.flow_code]!=null){
                avatar = flowsMap[msg.flow_code].icon;
            }

            chat_row.addClass("left");
            user_info = $('<div class="chat-info"><img src="'+avatar+'"  /><label class="chat-username">'+getFlow().name+'</label><div class="chat-time"><label>'+timeString+'</label></div></div>');
        } 
        
        chat_row.append(user_info);


        //box
        var box = $('<div class="chat-box"></div>');
        if(msg.role!="user"){
            box.append('<div class="chat-toolbar"><span class="chat-title"></span><a id="chat_copy_'+message_id+'" data-clipboard-target="#chat_item_'+message_id+'" class="btn btn-sm btn-outline-primary border-0" onclick="onCopy(this);" ><i class="fa fa-copy"></i>Copy</a></div>');
        }

        // 主体内容
        box.append('<div id="chat_item_'+message_id+'" class="chat-item"></div>');
        
        // 尾巴
        box.append('<div id="chat_footer_'+message_id+'" class="chat-footer"></div>');
 
        chat_row.append(box);

        if(prepend){
            $("#message_list").prepend(chat_row);
        }else{
            $("#message_list").append(chat_row);
        } 
    }
    
    //状态
    var finish = msg.finish;
    if(finish=='no'){
        chat_row.find(".chat-footer").html("正在输出...");
    }else{
        chat_row.find(".chat-footer").html("");
    }

    //内容
    var content = msg.content;

    var oldcontent = chat_row.find(".chat-item").attr("content")||'';

    var newcontent = oldcontent+content;
    chat_row.find(".chat-item").attr("content",newcontent);
 
     
    marked.use({
        async: true,
        headerIds: false,
        mangle: false,
        langPrefix: 'hljs language-',
        highlight: function(code, lang) {
          const language = hljs.getLanguage(lang) ? lang : 'javascript';
          return hljs.highlight(code, { language }).value;
        },
    });

    marked.parse(newcontent).then(res=>{ 
        chat_row.find(".chat-item").html(res); 

        $("#"+message_id+" code").each((index,el) => { 
        
            var codeid = $(el).attr("id"); 
            if(!codeid){
                codeid = "code_"+guid();
                $(el).attr("id",codeid);
            } 
            var toolbar =  $(el).parent().find("div.code-toolbar");
            if(toolbar==null || toolbar.length==0){
                var copyid = "btn_"+guid(); 
                $('<div class="code-toolbar"><a id="'+copyid+'" data-clipboard-target="#'+codeid+'" class="btn btn-sm btn-outline-primary border-0" onclick="onCopy(this);"><i class="fa fa-copy"></i>Copy</a></div>').insertBefore($(el));
            }  
     
        }); 
        
        if(toBottom){
            //滚动到最下
            scrollToBottom();
        }
        
    });  

     
}

//回车发送
function messageKeydown(event){
   
    if((event.ctrlKey || event.shiftKey || event.metaKey) && event.keyCode === 13) {
        $("#message").val($("#message").val()+"\n");
        return false;
    }else if (event.keyCode === 13){
        sendMessage();
        return false;
    }
 
    return true;
}

//发送信息
function sendMessage(){
    var content = $("#message").val();

    if(content.length==0){
        return;
    }

    var session_id = getSessionId();
    var user_id = getUserId();
    var flow = getFlow();
    if(flow==null){
        return;
    } 
    var flow_code = flow.code;

    var flow_params = flow.params;
    var params={};
    for(var i in flow_params){
        params[flow_params[i].name] = flow_params[i].value;
    }
    var message_id = guid();

    var msg={
        message_id: message_id,
        session_id: session_id,
        user_id:user_id,
        flow_code: flow_code, 
        message_type:"message",
        role:"user",
        format:"text",
        params: params,
        content: content,
        send_time: Date.now()
    };
    
    appendMessage(msg,false, true);

    var msgJson = JSON.stringify(msg);

    websocket.send(msgJson);

    document.getElementById("message").innerHTML = "";
    $("#message").html("");
    $("#message").val("");
    
    $("#message").focus();
}


//加载历史消息
function loadMessages(start, size, callback){
    if(start==undefined){
        start=0;
    }
    if(size==undefined){
        size=message_page_size;
    }

    var session_id = getSessionId(); 
    var user_id = getUserId();
    var flow  = getFlow(); 

    if(flow==null){
        return;
    }
    if(session_id==null || session_id.length==0){
        return;
    }
    if(user_id==null || user_id.length==0){
        return;
    }
 
    var flow_code = flow.code;

    loading_messages = true;

    http.post(http_url_namespace+"/session/load_messages", {user_id: user_id, flow_code: flow_code, session_id: session_id, start: start, size: size}, "form", function(res){
        loading_messages = false;
        if(res.code==0){
            var messages = res.obj;
            if(messages){
                
                if(callback){
                    callback(messages);
                }

            }
            
        }else{  
            toastr.error(res.msg); 
        } 

    },function(err){ 
        loading_messages=false;
        toastr.error(err);  
    });
}

//新建会话
function newSession(){
    var flow = getFlow();
    if(flow==null ||flow.code==null || flow.code==""){
        openFlowBox();
        return;
    }

    var session_id=guid();
   
    selectSession(session_id);

    clearMessages();
    
}

//切换选择会话
function selectSession(session_id){
    setSessionId(session_id);
    var title = "";

    if(sessionMap[session_id]!=null){
        title = sessionMap[session_id].title||"";
    }

    $("#nav_session_title").html(title); 

    $("#session_list").find(".session-item").each(function(index,e){
        $(e).find('.nav-link').removeClass("active");
    });

    var item = $("#session_list").find(".session-item[session_id='"+session_id+"']");
    if(item.length>0){
        item.find('.nav-link').addClass("active");
    }


    clearMessages();
    
    loadMessages(0, message_page_size, function(messages){
        for(var i in messages){
            var msg=messages[i];
            
            appendMessage(msg,true, false);
        }

        setTimeout(scrollToBottom, 500);

    }); 
}

function removeSession(session_id){
    if(session_id==null || session_id.length==0){
        return;
    }

    isconfirm("确认删除？",function(){
        var user_id=getUserId();  
        var flow = getFlow(); 
        if(flow==null){
            return;
        }
        if(user_id==null || user_id.length==0){
            return;
        }
        
        var flow_code = flow.code;

        http.post(http_url_namespace+"/session/remove", {user_id: user_id, flow_code: flow_code,session_id: session_id}, "form", function(res){
            if(res.code==0){
                  
                loadSessions(); 
                clearMessages();

            }else{ 
                toastr.error(res.msg); 
            } 
    
        },function(err){ 
            toastr.error(err);  
        });
    });

}
//显示会话列表
function showSessions(infos){
    
    $("#session_list .session-item").each(function(index,e){
        $(e).remove();
    });
    $("#nav_session_title").html(""); 

    if(infos){
        var colors = ["#007bff","#28a745","#dc3545","#ffc107","#f8f9fa"];

        for(var i in infos){
            var info=infos[i];
            var title = info.title||''; 
            
            sessionMap[info.id] = info;

            if(title.length<1){
                continue;
            }
 
            title = title.replaceAll("\n","");
            if(title.length>10){
                title = title.substr(0,10)+"...";
            }
            var first= title.substr(0,1);
            
            var createTime = new Date(info.create_time).toLocaleString();

            var color = colors[i%colors.length]
        
            var item_html = '<li class="session-item nav-item" session_id="'+info.id+'" style="position:relative;" >'+
            '<a  class="nav-link d-flex justify-content-start align-items-center"  onclick="selectSession(\''+info.id+'\');resetSidebar();return;">'+
            '<div class="word-icon d-none visible-sidebar-mini" style="color:'+color+';">'+first+'</div>'+
            '<div class="brand-text">'+
                '<div id="side_session_title" class="session-title">'+title+'</div>'+
                '<div class="session-time">'+createTime+'</div>'+   
            '</div>'+
            '</a>'+
            '<a class="brand-text" style="position:absolute; top: 10px; right: 10px;z-index: 2" onclick="removeSession(\''+info.id+'\')"><i class="fa fa-times"></i></a>'+
            
            '</li>';

            var item = $(item_html);
            
            if(info.id == getSessionId()){
               
                $("#nav_session_title").html(title);
                item.find(".nav-link").addClass("active");
            } 

            $("#session_list").append(item);
            
        }
    }
}
//加载会话
function loadSessions(){
    $("#session_list").html("");

    var user_id=getUserId();  
    var flow = getFlow(); 
    if(flow==null){
        return;
    }
    if(user_id==null || user_id.length==0){
        return;
    }
    
    var flow_code = flow.code;

    http.post(http_url_namespace+"/session/load_infos", {user_id: user_id, flow_code: flow_code}, "form", function(res){
        if(res.code==0){
            var infos = res.obj;
            showSessions(infos);
            
        }else{ 
            toastr.error(res.msg); 
        } 

    },function(err){ 
        toastr.error(err);  
    });
 
}

//选择prompt
function selectPrompt(name, obj){
    var content=$(obj).find(".prompt-content").html();
    var input = $("#params_list").find("[name='"+name+"']");
    if(input){
        input.val(content);
    }
    $("#prompt_selecter_"+name).hide();
}
//显示 prompt
function showPrompts(name, prompts){
     
    $("#prompt_selecter_"+name+" .prompt-list").html("");
    for(var i in prompts){
        var title = prompts[i].title;
        var content = prompts[i].content;
        
        var item = $('<div class="prompt-item" onclick="selectPrompt(\''+name+'\',this)"><div class="prompt-title"><i class="fa fa-book"></i> '+title+'</div><div class="prompt-content">'+content+'</div></div>');
         
        $("#prompt_selecter_"+name+" .prompt-list").append(item);
    }
}

//prompt loader
function switchPromptsSelecter(name, obj){
    if($("#prompt_selecter_"+name).is(":visible")){
        $("#prompt_selecter_"+name).hide();
        $(obj).find(".fa").removeClass("fa-angle-up");
        $(obj).find(".fa").addClass("fa-angle-down");

    }else{
        $("#prompt_selecter_"+name).show();
        $(obj).find(".fa").addClass("fa-angle-up");
        $(obj).find(".fa").removeClass("fa-angle-down");

        if(current_prompts!=null){
            showPrompts(name, current_prompts);
        }else{
            http.post(http_url_namespace+"/chat/prompts", {}, "form", function(res){
                if(res.code==0){
                    var prompts = res.obj;
                    current_prompts = prompts; 
                    showPrompts(name, current_prompts);
                     
                } else {
                    toastr.error("加载Prompt失败");  
                }
        
            },function(err){ 
                toastr.error("加载Prompt失败");  
            });
        }
        
 
    } 

}

function showOrHide(name,obj){


    var tp = $("input[name='"+name+"']").attr("type");
    if(tp=="password"){
        $(obj).find("i").addClass("fa-eye-slash");
        $(obj).find("i").removeClass("fa-eye");
        $("input[name='"+name+"']").attr("type","text");
    }else{
        $(obj).find("i").addClass("fa-eye");
        $(obj).find("i").removeClass("fa-eye-slash");
        $("input[name='"+name+"']").attr("type","password");
    }
}

//重设参数为默认值
function resetUserFlowParam(name){

    isconfirm("确认重置为默认值？",function(){
        var input = $("#params_list").find("[name='"+name+"']");
        if(input && input.length>0){
            var flow = getFlow();
            if(flow && flow.code){
                var defaultFlow = flowsMap[flow.code];
                if(defaultFlow && defaultFlow.params){
                    for(var i in defaultFlow.params){
                        if(defaultFlow.params[i].name == name){
                            input.val(defaultFlow.params[i].value||'');
                        } 
                    } 
                } 
            } 
        }
    });
    
}

//显示流程参数
function showUserFlowParams(params){
    $("#params_list").html("");
    for(var i in params){
        var param = params[i];
        var label = param.label;
        var name = param.name;
        var value = param.value;

        //如果有全局参数已经配置，可以默认用全局参数，用户只需要确认。
        if(value==null || value=="" ){
            if(globalParams[name]!=null && globalParams[name].length>0){
                value = globalParams[name];
            }
        }

        var input_type = param.input_type;
        var input_html='';
        if(input_type=="text"){
            input_html = '<div class="input-group">'+ 
            '<input name="'+name+'" class="form-control "  type="text"  autocomplete="off" />'+
            '<a class="btn btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+
            '</div>';
        }else if(input_type=="number"){
            input_html = '<div class="input-group">'+ 
            '<input name="'+name+'" class="form-control " type="number" autocomplete="off" />'+
            '<a class="btn btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+
            '</div>';
        }else if(input_type=="textarea"){
            input_html = '<div class="input-group">'+ 
            '<textarea name="'+name+'" class="form-control " rows="2" autocomplete="off" ></textarea>'+
            '<a class="btn btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+
            '</div>';
        }else if(input_type=="password"){
            input_html = '<div class="input-group">'+ 
            '<input name="'+name+'" class="form-control " type="password"  autocomplete="new-password"/>'+
            '<a class="btn btn-default" onclick="showOrHide(\''+name+'\',this)"><i class="fa fa-eye"></i></a>'+
            '<a class="btn btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+
            '</div>';
        }else if(input_type=="chatgpt_model"){
            input_html = '<div class="input-group">'+ 
            '<select name="'+name+'" class="form-control " type="password" >'+
            '<option value="gpt-4">gpt-4</option>'+
            '<option value="gpt-4-0613">gpt-4-0613</option> '+
            '<option value="gpt-4-32k">gpt-4-32k</option>'+
            '<option value="gpt-4-32k-0613">gpt-4-32k-0613</option> '+
            '<option value="gpt-3.5-turbo">gpt-3.5-turbo</option>'+
            '<option value="gpt-3.5-turbo-0613">gpt-3.5-turbo-0613</option>'+
            '<option value="gpt-3.5-turbo-16k">gpt-3.5-turbo-16k</option>'+
            '<option value="gpt-3.5-turbo-16k-0613">gpt-3.5-turbo-16k-0613</option>'+
            '</select>'+
            '<a class="btn  btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+
            '</div>';
        }else if(input_type=="prompt"){
            input_html = '<div class="input-group">'+ 
            '<textarea name="'+name+'" class="form-control " rows="4" autocomplete="off"></textarea>'+
            '<a class="btn  btn-default" onclick="switchPromptsSelecter(\''+name+'\',this)" ><i class="fa fa-angle-down"></i></a>'+ 
            '<a class="btn  btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+ 
            '</div>';


            
            input_html +='<div  id="prompt_selecter_'+name+'"  class="prompt-box"><div class="prompt-list"></div></div>';
 

        }else{
            input_html = '<div class="input-group">'+ 
            '<input name="'+name+'" class="form-control "  type="text"/>'+
            '<a class="btn btn-default" onclick="resetUserFlowParam(\''+name+'\')"><i class="fa fa-redo"></i></a>'+
            '</div>';
        }

        var html='<div class="params-item form-group">'+
        '<label class="params-label">'+(label||name)+'</label>'+
        '<span class="params-description">'+(param.description||'')+'</span>'+
        
        input_html+
        
        '</div>'+
        '</div>';

        var item = $(html);
        
        item.find("[name='"+name+"']").val(value);

        $("#params_list").append(item);
    }


}

function loadUserFlowParams(callback){
    var flow = getFlow();
    if(flow==null){
        return;
    }
    var flow_code=flow.code;
    var flow_params = flow.params;

    var user_id = getUserId();
 
    http.post(http_url_namespace+"/chat/load_user_chatflow_param", {user_id: user_id, flow_code: flow_code}, "form", function(res){
        if(res.code==0){
            var userParams = res.obj;
            
            if(userParams!=null && userParams.length>0 && flow_params!=null && flow_params.length>0){
                for(var i in flow_params){ 
                    var pname = flow_params[i].name;
                    for(var j in userParams){
                        if(pname == userParams[j].name && userParams[j].value!=null && userParams[j].value.length>0){
                            flow_params[i].value = userParams[j].value;
                        }
                    }
                    //如果全局参数为空，可以把当前这个参数设置为全局参数，作为其他流程参数借鉴使用。
                    if(globalParams[pname]==null){
                        globalParams[pname] = flow_params[i].value;
                    }
                }
                flow.params = flow_params; 
                setFlow(flow);
            } 
        }else{ 
            toastr.error(res.msg); 
        } 

        showUserFlowParams(flow_params);

        if(callback){
            callback(flow_params);
        }
    },function(err){ 
        toastr.error(err);  
    });
}

function saveUserFlowParams(){
   
    var flow = getFlow();
    if(!flow){
        return;
    }

    var user_id = getUserId(); 
    if(!user_id){
        return;
    }

    var flow_code = flow.code;
    var flow_params = flow.params;
    var user_params=[];

    $("#params_list").find(".params-item").each(function(index,el){
        var item = $(el).find("[name]");
        if(item && item.length>0){
            var name = item.attr("name");
            if(!name || name.length==0){
                return;
            }
            var value = item.val();
            user_params.push({name:name,value:value}) ;
        }
    });
 

    if(user_params!=null && user_params.length>0 && flow_params!=null && flow_params.length>0){
        for(var i in flow_params){ 
            var pname = flow_params[i].name;

            for(var j in user_params){
                if(pname == user_params[j].name && user_params[j].value!=null && user_params[j].value.length>0){
                    flow_params[i].value = user_params[j].value;
                }
            }
            //如果全局参数为空，可以把当前这个参数设置为全局参数，作为其他流程参数借鉴使用。
            if(globalParams[pname]==null){
                globalParams[pname] = flow_params[i].value;
            } 
        }

        flow.params = flow_params;




        setFlow(flow);
 
        var data = JSON.stringify({user_id: user_id, flow_code: flow_code, params: flow_params});

        http.post(http_url_namespace+"/chat/save_user_chatflow_param", data, "json", function(res){
            if(res.code==0){
                
                closeUserFlowParamsModal();

                toastr.success(res.msg);
            }else{ 
                toastr.error(res.msg); 
            } 
        },function(err){ 
            toastr.error(err);  
        });


    } 

}

function selectFlow(code){
 
    var flow = flowsMap[code]; 
    if(flow==null){
        return;
    }
    
    setFlow(flow);
 
    $("#flow_name").html(flow.name); 

    $("#flow_icon").attr("src", flow.icon|| (http_url_namespace+'/static/img/service.png') );

    $("#flow_list").find(".flow-item").each(function(index,e){
        $(e).find(".nav-link").removeClass("active");
    });
    $("#flow_list").find(".flow-item[flow_code='"+code+"'] .nav-link").addClass("active");
 

    closeFlowBox();
 
    loadSessions(); 

    clearMessages();
    
    loadMessages(0, message_page_size,function(messages){
        for(var i in messages){
            var msg=messages[i]; 
            appendMessage(msg, true, false);
        }

        setTimeout(scrollToBottom, 500);
    });
 
    loadUserFlowParams(function(params){
        var needSet = false;
        for(var i in params){
            if(params[i].value==null || params[i].value==""){
                needSet=true;
                break;
            }
        }

        if(needSet){
            setTimeout(openUserFlowParamsModal,500);
        }

    }); 

   
 
}

function showFlows(flows){
    $("#flow_list").html("");
    var currentFlow=getFlow();

    for(var i in flows){
        var code = flows[i].code;
        var name = flows[i].name;
        var icon = flows[i].icon;

        var description = flows[i].description||'';

        var html='<div class="col-md-3 col-sm-6 col-12">'; 
        html+='<a  flow_code="'+code+'" class="flow-item btn btn-light" onclick="selectFlow(\''+code+'\');"  style="overflow:hidden;">';
        html+='<div class="flow-icon"><img src="'+icon+'"/></div>';
        html+='<div class="flow-info">';
        html+='<div class="flow-info-title">'+name+'</div>';
        html+='<div class="flow-info-description">'+description+'</div>';
        html+='</div>';

        html+='</a>';
        html+='</div>';
        var item = $(html);

        if(currentFlow!=null && code==currentFlow.code){
            item.find(".nav-link").addClass("active");
        }
        $("#flow_list").append(item);
    }
}

function loadFlows(callback){
    http.post(http_url_namespace+"/chat/load_flows", {}, "form", function(res){
        if(res.code==0){
            var flows = res.obj;

            for(var i in flows){
                var code = flows[i].code; 
                flowsMap[code] = flows[i];
            }

            showFlows(flows);

            if(callback){
                callback(flows);
            }
        }else{ 
            toastr.error(res.msg); 
        } 

    },function(err){ 
        toastr.error(err);  
    });
}

function loadChatconfig(){
    http.post(http_url_namespace+"/chatconfig/load", {}, "form", function(res){
        if(res.code==0){

            var config = res.obj;
             
            if(config){ 
                if(config.logo && config.logo.length>0){
                    $("#logo_img").attr("src",config.logo);
                }
                if(config.title && config.title.length>0){
                    $("#logo_title").html( config.title );
                    document.title = config.title;
                } 
            } 
 
        }else{
             
        }

    });
}


function closeFlowBox(){  

    $("#flow_box").hide(); 
    $("#message_box").show(); 
    $(".main-footer").show();

}

function openFlowBox(){ 
    $("#flow_box").show();  
    $("#message_box").hide(); 
    $(".main-footer").hide();

    var flow = getFlow();

    if(flow==null || flow.code==null || flow.code==""){
        $("#flow_backward_btn").hide();
    }else{
        $("#flow_backward_btn").show();
    }

}

function openSessionTitleModal(){
    var session_id = getSessionId();
    if(session_id==null || session_id==""){
        return;
    }
    var info =  sessionMap[session_id];
    if(info==null){
        return;
    }
    $("#modal_session_title input[name='session_title']").val(info.title);
    $("#modal_session_title").modal("show");
}

function closeSessionTitleModal(){
    $("#modal_session_title").modal("hide"); 
}

function saveSessionTitle(){
    var user_id = getUserId();

    if(user_id==null || user_id==""){
        return;
    }
    var flow = getFlow();
    if(flow==null || flow.code==null || flow.code==""){
        return;
    }

    var session_id = getSessionId();
    if(session_id==null || session_id==""){
        return;
    }

    var title = $("#modal_session_title input[name='session_title']").val();   

    http.post(http_url_namespace+"/session/save_title", {user_id:user_id,flow_code: flow.code, session_id: session_id, title:title}, "form", function(res){
        if(res.code==0){
            
            if(sessionMap[session_id]!=null){
                sessionMap[session_id].title = title;
            }

            $("#nav_session_title").html(title);
            $("#session_list li[session_id='"+session_id+"'] #side_session_title").html(title);
            closeSessionTitleModal();
        }else{ 
            toastr.error(res.msg); 
        } 

    },function(err){ 
        toastr.error(err);  
    });

}   

function closeUserFlowParamsModal(){
    $("#modal_params").modal("hide"); 
}

function openUserFlowParamsModal(){
    var flow = getFlow();
    if(flow==null || flow.code==null || flow.code==""){
        openFlowBox();
        return;
    }

    loadUserFlowParams();

    $("#modal_params #param_flow_name").html(flow.name);

    $("#modal_params").modal({backdrop: 'static', keyboard: false});
    $("#modal_params").modal("show");
}

function resetSidebar(){

    var has_sidebar_open = $("body").hasClass("sidebar-open");
    if(has_sidebar_open){
        $("body").removeClass("sidebar-open");
        $("body").addClass("sidebar-closed");
        $("body").addClass("sidebar-collapse");
        
    }
}
 
function initScrollEvent(){
    $(window).scroll(function(e) {
        var obj = $(this); 
 
        var scrollTop = obj.scrollTop(); //滚动条top
      
        if (loading_messages == false && scrollTop < 0.02) {
            
            const oldFirstObjId = $('.message-list').children(':first').attr('id');

            
            const start = $('.message-list').children().length;
           
            loadMessages(start, message_page_size, function (messages) { 
            
                for(var i in messages){
                    var msg=messages[i]; 
                    appendMessage(msg, true, false);
                }
            
                  

            });
        
            
        } 
    });

    
}
  

$(function(){ 
    initScrollEvent();

    conn();
    
    loadChatconfig();

    loadFlows(function(flows){

        var flow=getFlow(); 
        if(flow!=null){ 
           
            selectFlow(flow.code); 
        } else {
            $("#flow_name").html("请选择场景");
            openFlowBox();
        }

    }); 

});
     
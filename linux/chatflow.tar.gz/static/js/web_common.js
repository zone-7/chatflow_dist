var http_url_namespace="/chatflow";

var actions = {};
var meta={tags:[],meta_data:[]};

var toastr_position="toast-center-center";//"toast-top-full-width";
if(window.innerWidth<=768){
    toastr_position="toast-top-full-width";
}


toastr.options = { 
    "closeButton": true,
    "showDuration": "300",//显示动作时间
    "hideDuration": "300",//隐藏动作时间
    "positionClass": toastr_position
};


function guid() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
		var r = Math.random() * 16 | 0,
			v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
} 


function getUrlPath(){
    var path = window.location.pathname;
    return path.replace(http_url_namespace,"");

}

function getUrlParam(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r!=null) return unescape(r[2]); return null; //返回参数值
} 

//确认
function mustconfirm(msg, callback){
    toastr.info(msg+"<br /><div  style='text-align:right;'><button type='button' id='confirmationButtonYes' class='btn btn-sm btn-light m-1'>确 定</button></div>", '确认',
    {
        closeButton: false,
        allowHtml: true,
        extendedTimeOut: 1000*60*24,
        timeOut: 1000*60*24,
        tapToDismiss: false,
        positionClass: toastr_position,
        onShown: function (toast) {
            $("#confirmationButtonYes").click(function(){ 
                toastr.clear();
                if(callback){
                    callback();
                }
            }); 
        }
    });

}
//确认
function isconfirm(msg, callback, cancel){

    
    toastr.info(msg+"<br /><div  style='text-align:right;'><button type='button' id='confirmationButtonNo' class='btn btn-sm btn-light m-1'>取 消</button><button type='button' id='confirmationButtonYes' class='btn btn-sm btn-light m-1'>确 定</button></div>", '确认',
    {
        closeButton: false,
        allowHtml: true,
        extendedTimeOut: 1000*60*24,
        timeOut: 1000*60*24, 
        positionClass: toastr_position,
        onShown: function (toast) {
            $("#confirmationButtonYes").click(function(){ 
                toastr.clear();

                if(callback){
                    callback();

                }

            });
            $("#confirmationButtonNo").click(function(){ 
                toastr.clear();
                if(cancel){
                    cancel();
                }
            });
        }
    });
}

//输入
function prompt_confirm(msg, callback, cancel){

    toastr.info("<input id='confirm_prompt' class='form-control form-control-sm'/><br /><div  style='text-align:right;'><button type='button' id='confirmationButtonNo' class='btn btn-sm btn-light m-1'>取 消</button><button type='button' id='confirmationButtonYes' class='btn btn-sm btn-light m-1'>确 定</button></div>", msg,
    {
        closeButton: true,
        allowHtml: true,
        extendedTimeOut: 1000*60*24,
        timeOut: 1000*60*24, 
        tapToDismiss: false,
        positionClass: toastr_position,
        onShown: function (toast) {
            $("#confirmationButtonYes").click(function(){ 
                
                var value = $("#confirm_prompt").val();
         
                if(callback){
                    callback(value); 
                }
                toastr.remove();

            });
            $("#confirmationButtonNo").click(function(){ 
                
                if(cancel){
                    cancel();
                }
                toastr.remove(); 
            });
        }
    });
}
function goPage(page,target){
    if(!target){
        target="_self";
    }
    var token = localStorage.getItem("token")||"";
    if(page.indexOf("?")>=0){
        page += "&token="+token;
    }else{
        page += "?token="+token;
    }
    if(target=="_self"){
        location.href = http_url_namespace + page;
    }else{
        window.open(http_url_namespace + page);
    }
    

}

function getVersion(callback){
    http.post(http_url_namespace+"/version", {}, "form", function(res){
         
        if(res.code==0 && callback){ 
            callback(res.obj);
        } 

    },function(err){   
    });
}

function login(){
    var username = $("input[name='username']").val();
    var password = $("input[name='password']").val();
    password = md5(password);
    http.post(http_url_namespace+"/auth/login", {username: username, password:password}, "form", function(res){
         
         if(res.code==0){
             window.localStorage.setItem("token", res.obj);
 
             window.location.href = http_url_namespace+"?token="+res.obj; 
         }else{  
             toastr.error(res.msg); 
         } 
 
     },function(err){  
         toastr.error(err);  
     });
 
 }
 function logout(){
    token = localStorage.getItem("token");

    http.post(http_url_namespace+"/auth/logout", {token: token}, "form", function(res){ 
         if(res.code==0){
            localStorage.removeItem("token");

            window.location.href = http_url_namespace; 

         }else{  
             toastr.error(res.msg); 
         } 
 
     },function(err){  
         toastr.error(err);  
     });
 
 }
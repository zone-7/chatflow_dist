
var chatflowMap={};

var chatflows_offline = []; 
var chatflows_online = []; 

function saveChatconfig(){
    var onlines = [];
  
    $("#online_list").find(".flow-item").each(function(index,el){
      var code = $(el).attr("code");
      var order_num=index * 1;
      onlines.push({code: code, order_num: order_num*1});
    });
    
    var title = $("input[name='title']").val();

    var logo = $("#logo_img").attr("data");

    var config={title:title,logo: logo, onlines: onlines};
    
    http.post(http_url_namespace+"/chatconfig/save", JSON.stringify(config), "json", function(res){
      if(res.code==0){
        toastr.success(res.msg);
      }else{
        toastr.error(res.msg);
      }
    });
}

//排序up
function upFlow(code){
   var item = $("#online_list").find(".flow-item[code='"+code+"']");
 
   item.prev().before(item);
}
//排序down
function downFlow(code){
    var item = $("#online_list").find(".flow-item[code='"+code+"']");
  
    item.next().after(item);
}



function appendFlow(code){
    $("#flow_list").find(".flow-item[code='"+code+"']").remove();

    addOnline(chatflowMap[code]);

}

function removeFlow(code){
    $("#online_list").find(".flow-item[code='"+code+"']").remove();

    addOffline(chatflowMap[code]);
}

function addOnline(item){
    item.icon = item.icon || (http_url_namespace+'/static/img/empty.png'); 
    var html='<li class="flow-item nav-item d-flex  justify-content-between" code="'+item.code+'">'+
    '<div>'+
    '<img src="'+item.icon+'" class="flow-item-icon" style="width:28px"/>'+ 
    '<label>'+item.name+'</label>'+
    '</div>'+
    '<div class="btn-group">'+
    '<a class="btn btn-sm btn-outline-primary" onclick="removeFlow(\''+item.code+'\')"><i class="fa fa-trash"></i></a>'+

    '<a class="btn btn-sm btn-outline-primary" onclick="upFlow(\''+item.code+'\')"><i class="fa fa-arrow-up"></i></a>'+
    '<a class="btn btn-sm btn-outline-primary" onclick="downFlow(\''+item.code+'\')"><i class="fa fa-arrow-down"></i></a>'+

    '</div>'+
    '</li>';//end flow-item
    
    var box = $(html); 
    
    $("#online_list").append(box); 
}

function showChatflows_online(){
    $("#online_list").html(""); 
    for(var i in chatflows_online){
        var item = chatflows_online[i];
        addOnline(item);
    }
}

function addOffline(item){
    item.icon = item.icon || (http_url_namespace+'/static/img/empty.png'); 
    var html='<li class="flow-item nav-item  d-flex justify-content-between" code="'+item.code+'">'+
    '<div>'+
    '<img src="'+item.icon+'" class="flow-item-icon" style="width:28px"/>'+ 
    '<label>'+item.name+'</label>'+
    '</div>'+
    '<div>'+
    '<a class="btn btn-sm btn-outline-primary" onclick="appendFlow(\''+item.code+'\')"><i class="fa fa-plus"></i></a>'+
    '</div>'+
    '</li>';//end flow-item
    
    var box = $(html); 
    
    $("#flow_list").append(box); 
}
function showChatflows_offline(){
    
    $("#flow_list").html(""); 
    for(var i in chatflows_offline){
        var item = chatflows_offline[i];
        addOffline(item);
    }

}

function loadChatconfig(){
    http.post(http_url_namespace+"/chatconfig/load", {}, "form", function(res){
        if(res.code==0){

            var config = res.obj;
             
            if(config){ 
                
                $("#logo_img").attr("src", (config.logo || (http_url_namespace+'/static/img/empty.png')));
                $("#logo_img").attr("data", config.logo); 
                $("input[name='title']").val(config.title); 
            } 

            if(config!=null && config.onlines){ 
                for(var i in config.onlines){

                    var item = config.onlines[i];
                    var code = item.code;
                    var order_num = item.order_num;

                    var index = -1;
                    for(var j in chatflows_offline){
                        if(code == chatflows_offline[j].code){
                            index = j;
                            break;
                        } 
                    }
                    
                    if(index>=0){
                        chatflows_online.push(chatflows_offline[index]);
                        chatflows_offline.splice(index, 1);
                    } 
                 
                }  
            } 

            showChatflows_offline();
            showChatflows_online();
        }else{
            toastr.error(res.msg);
        }

    });
}


//列出所有流程
function loadChatflows(){
    http.post(http_url_namespace+"/flow/list", {}, "form", function(res){
        if(res.code==0){
            var list = res.obj;
            
            for(var i in list){
                chatflowMap[list[i].code] = list[i];
            }

            chatflows_offline = list;

            loadChatconfig();
        }else{
            toastr.error(res.msg);
        }
        
    });
}


function initIconEvent(){

   // 初始化插件
    $("#logo").fileinput({
        language: 'zh',
        showUpload: false, 
        showCaption: false,//是否显示标题
        showPreview: false,
        showRemove:false,
        captionClass: "form-control-sm",
        browseClass: "btn btn-primary btn-sm",
        removeClass: "btn btn-default btn-sm",
        allowedFileExtensions: ['jpg', 'png', 'gif'],
        maxFileSize: 1000,
        maxFilesNum: 1,
        browseLabel:'选择',
        removeLabel:'删除',
        cancelLabel:'取消',
        msgPlaceholder:'请选择图片',
        dropZoneTitle: "上传图片建议64*64"
    
    });
    // 获取图片并base64编码
    $("#logo").on("filebatchselected", function(event, files) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var base64Img = e.target.result;
            $("#logo_img").attr("src",base64Img);
            $("#logo_img").attr("data",base64Img);
            console.log(base64Img);
        };
        reader.readAsDataURL(files[0]);
    });
    $('#logo').on('fileclear', function(event, id) { 
        $("#icon_logo_imgimg").attr("src","");
        $("#logo_img").attr("data","");
        
    });
}


$(function(){
    initIconEvent();
    loadChatflows();

});